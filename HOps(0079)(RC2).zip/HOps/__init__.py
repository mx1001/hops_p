'''
Copyright (C) 2015 masterxeon1001
masterxeon1001@gmail.com

Created by masterxeon1001 and team

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

bl_info = {
    "name": "Hard Ops v.0079(f)",
    "description": "A joint tactical modelling endeavor for experimental modelling and concept mesh creation.",
    "author": "MX, IS, RF, JM, AR, BF, SE, PL, MKB, CGS, PG, Adam K, Wazou, Pistiwique, Jacques and you",
    "version": (0, 0, 7, 9),
    "blender": (2, 76, 0),
    "location": "View3D",
    #"warning": "Hard Ops - The Global Bevelling Offensive V 007x",
    "wiki_url": "https://masterxeon1001.wordpress.com/2016/02/23/hard-ops-007-intro-guide/",
    "category": "Object" }


from . import developer_utils
modules = developer_utils.setup_addon_modules(__path__, __name__, "bpy" in locals())

import bpy,bgl,blf
from . registration import register_all, unregister_all

def register():
    bpy.utils.register_module(__name__)
    register_all()
    print("Registered {} with {} modules".format(bl_info["name"], len(modules)))

def unregister():
    bpy.utils.unregister_module(__name__)
    unregister_all()
    print("Unregistered {}".format(bl_info["name"]))
