import os
import bpy
from bgl import *
from bpy.props import *
from math import radians, degrees
from ... utils.context import ExecutionContext
from ... preferences import tool_overlays_enabled
from ... utils.blender_ui import get_location_in_current_3d_view
from ... overlay_drawer import show_custom_overlay, disable_active_overlays
from ... graphics.drawing2d import set_drawing_dpi, draw_horizontal_line, draw_boolean, draw_text
from ... overlay_drawer import show_text_overlay

class reset_status(bpy.types.Operator):
    bl_idname = "hops.reset_status"
    bl_label = "Reset Status"
    bl_description = "Resets the Mesh Status For Workflow Realignment"
    bl_options = {"REGISTER", "UNDO"}
    
    @classmethod
    def poll(cls, context):
        return True
    
    def execute(self, context):
        object = bpy.context.active_object
        object.hops.status = "UNDEFINED"
        
        try: self.wake_up_overlay()
        except: pass
        
        return {"FINISHED"}
    
    def invoke(self, context, event):
        self.execute(context)
        
        object = bpy.context.active_object
        if tool_overlays_enabled():
            disable_active_overlays()
            self.wake_up_overlay = show_custom_overlay(draw,
                #parameter_getter = self.parameter_getter,
                location = get_location_in_current_3d_view("CENTER", "BOTTOM", offset = (0, 130)),
                location_type = "CUSTOM",
                stay_time = 2,
                fadeout_time = 0.8)

        return {"FINISHED"}
        
# Overlay
###################################################################

def draw(display,):
#def draw(display, parameter_getter):
    #sharpness, auto_smooth_angle, additive_mode, sub_d_sharpening, segment_amount, bevelwidth = parameter_getter()
    scale_factor = 0.9

    glEnable(GL_BLEND)
    glEnable(GL_LINE_SMOOTH)

    set_drawing_dpi(display.get_dpi() * scale_factor)
    dpi_factor = display.get_dpi_factor() * scale_factor
    line_height = 18 * dpi_factor

    transparency = display.transparency
    color = (1, 1, 1, 0.5 * transparency)

    # Middle
    ########################################################

    location = display.location
    x, y = location.x, location.y
    x, y = x - 120 * dpi_factor, y - 27 * dpi_factor
    
    line_length = 270

    line_width = 2 * dpi_factor
    draw_horizontal_line(x,  y, line_length * dpi_factor + 65, color, width = line_width)

    draw_text("MESH RESET", x, y - 22 * dpi_factor,
              align = "LEFT", size = 16, color = color)

    draw_horizontal_line(x, y - 31 * dpi_factor, line_length * dpi_factor + 65, color, width = line_width)

    draw_text("MESH STATUS RESET TO UNDEFINED", x + line_length * dpi_factor, y - 42 * dpi_factor,
              align = "RIGHT", size = 9, color = color)


    glDisable(GL_BLEND)
    glDisable(GL_LINE_SMOOTH)