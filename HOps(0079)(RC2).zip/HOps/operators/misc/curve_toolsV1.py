import bpy
from bgl import *
from bpy.props import *
from math import radians, degrees

class makeTaperOperator(bpy.types.Operator):
    bl_idname = "hops.make_Taper"
    bl_label = "MakeTaper"
    bl_options = {"REGISTER", "UNDO"}
    bl_description = ""
    
    @classmethod
    def poll(cls, context):
        if getattr(context.active_object, "type", "") != "CURVE": return False
        return True

    def draw(self, context):
        layout = self.layout

    def invoke(self, context, event):
        self.execute(context)
        return {"FINISHED"} 
    
    def execute(self, context):
        target = context.active_object
        tapers = self.get_taper_objects()

        set_taper_object(target, tapers)
        only_select(cutters)
        return {'FINISHED'}
       
    @classmethod
    def get_taper_objects(cls):
        selection = bpy.context.selected_objects
        active = bpy.context.active_object
        return [object for object in selection if object != active and object.type == "CURVE"]

def set_taper_object(target, tapers):
    bpy.context.object.data.bevel_object = bpy.data.objects[tapers]
