import os
import bpy
import bmesh
from bgl import *
from bpy.props import *
from bpy.props import *
import bpy.utils.previews
from random import choice
from math import pi, radians
from math import radians, degrees
from ... operators.utils import update_bevel_modifier_if_necessary
from ... utils.context import ExecutionContext
from ... preferences import tool_overlays_enabled
from ... utils.blender_ui import get_location_in_current_3d_view
from ... overlay_drawer import show_custom_overlay, disable_active_overlays
from ... graphics.drawing2d import set_drawing_dpi, draw_horizontal_line, draw_boolean, draw_text
from ... utils.objects import get_modifier_with_type, apply_modifiers
from . complex_sharpen import complex_sharpen_active_object

class SstepOperator(bpy.types.Operator):
    bl_idname = "step.sstep"
    bl_label = "Sstep Operator"
    bl_description = "Bake Modifiers And Recalculate"
    bl_options = {"REGISTER", "UNDO"}
    
    text = "(S)Step - New bevels calculated."
    op_tag = "(S)Step"
    op_detail = "No new bevels were baked - Bools Baked"

    items = [(x.identifier, x.name, x.description, x.icon) 
                 for x in bpy.types.Modifier.bl_rna.properties['type'].enum_items]

    modifier_types = EnumProperty(name="Modifier Types",
                           items=[(id, name, desc, icon, 2**i) for i, (id, name, desc, icon) in enumerate(items)
                                   if id in ['BOOLEAN', 'MIRROR', 'BEVEL', 'SOLIDIFY', 'SUBSURF', 'ARRAY']],
                           description="Don't apply these",
                           default={'BEVEL', 'MIRROR','SUBSURF','ARRAY'},
                           options={'ENUM_FLAG'})

    segment_amount = IntProperty(name="Segments", description = "Segments For Bevel", default = 3, min = 1, max = 12)

    bevelwidth = FloatProperty(name="Bevel Width Amount",
                               description="Set Bevel Width",
                               default=0.0200,
                               min = 0.002,
                               max =1.50)

    sharpness = FloatProperty(name = "Sharpness", default = radians(30),
                              min = radians(1), max = radians(180), subtype = "ANGLE")

    auto_smooth_angle = FloatProperty(name = "Auto Smooth Angle", default = radians(60),
                              min = 0.0, max = radians(180), subtype = "ANGLE")

    additive_mode = BoolProperty(name = "Additive Mode",
                              description = "Don't clear existing edge properties",
                              default = True)

    sub_d_sharpening = BoolProperty(name = "Sub-D Sharpening")

    profile_value = 0.70

    reveal_mesh = False

    
    @classmethod
    def poll(cls, context):
        return getattr(context.active_object, "type", "") == "MESH"    

    def draw(self, context):
        layout = self.layout

        box = layout.box()
        col = box.column()
        
        #text = self.text
        #op_tag = self.op_tag
        #op_detail = self.op_detail
        
        col.prop(self, "modifier_types", expand=True)
        box.prop( self, 'sharpness', text = "(S)Step Angle" )
    
    def invoke(self, context, event):
        self.execute(context)

        if tool_overlays_enabled():
            disable_active_overlays()
            self.wake_up_overlay = show_custom_overlay(draw,
                parameter_getter = self.parameter_getter,
                location = get_location_in_current_3d_view("CENTER", "BOTTOM", offset = (0, 130)),
                location_type = "CUSTOM",
                stay_time = 2,
                fadeout_time = 0.8)

        return {"FINISHED"}

    def parameter_getter(self):
        return self.auto_smooth_angle, self.segment_amount, self.bevelwidth, self.op_detail, self.op_tag, self.text

    
    def execute(self, context):
        active = bpy.context.active_object

        complex_sharpen_active_object(
            context.active_object,
            self.sharpness,
            self.auto_smooth_angle,
            self.additive_mode,
            self.sub_d_sharpening,
            self.modifier_types,
            self.segment_amount,
            self.bevelwidth,
            self.reveal_mesh)

        update_bevel_modifier_if_necessary(
            context.active_object,
            self.segment_amount, 
            self.bevelwidth,
            self.profile_value)

        bpy.ops.object.select_all(action='DESELECT')
        active.select = True

        object = bpy.context.active_object
        object.hops.status = "CSTEP"

        try: self.wake_up_overlay()
        except: pass
    
        return {"FINISHED"}


class CstepOperator(bpy.types.Operator):
    bl_idname = "step.cstep"
    bl_label = "Cstep Operator"
    bl_description = "Bake Modifiers And Add New Bevel"
    bl_options = {"REGISTER", "UNDO"}
    
    text = "(C)Step - New bevels calculated."
    op_tag = "(C)Step"
    op_detail = "Bevels were baked and re-added"
    
    items = [(x.identifier, x.name, x.description, x.icon) 
                 for x in bpy.types.Modifier.bl_rna.properties['type'].enum_items]

    modifier_types = EnumProperty(name="Modifier Types",
                           items=[(id, name, desc, icon, 2**i) for i, (id, name, desc, icon) in enumerate(items)
                                   if id in ['BOOLEAN', 'MIRROR', 'BEVEL','ARRAY']],
                           description="Don't apply these",
                           default={'BOOLEAN', 'MIRROR','ARRAY'},
                           options={'ENUM_FLAG'})

    auto_smooth_angle = FloatProperty(name="AutoSmooth Angle",
                          description="Set AutoSmooth angle",
                          default= radians(60.0),
                          min = 0.0,
                          max = radians(180.0),
                          subtype='ANGLE')

    ssharpangle = FloatProperty(name="SSharpening Angle", 
                                description="Set SSharp Angle", 
                                default= 30.0, 
                                min = 0.0, 
                                max = 180.0)
    bevelwidth = FloatProperty(name="Bevel Width Amount", description="Set Bevel Width", default= 0.01, min = 0.002, max = 0.25)

    segment_amount = IntProperty(name="Segments", description = "Segments For Bevel", default = 3, min = 1, max = 12)

    bevelwidth = FloatProperty(name="Bevel Width Amount",
                               description="Set Bevel Width",
                               default=0.0200,
                               min = 0.002,
                               max =1.50)

    profile_value = 0.70
    
    @classmethod
    def poll(cls, context):
        """ob = context.object
        if ob is None:
            return False
        return (ob.type == 'MESH')"""
        return getattr(context.active_object, "type", "") == "MESH"    

    def draw(self, context):
        layout = self.layout
        box = layout.box()
        col = box.column()
        
        col.prop(self, "modifier_types", expand=True)
        box.prop( self, 'ssharpangle', text = "(S)Step Angle" )
    
    def invoke(self, context, event):
        self.execute(context)
        
        if tool_overlays_enabled():
            disable_active_overlays()
            self.wake_up_overlay = show_custom_overlay(draw,
                parameter_getter = self.parameter_getter,
                location = get_location_in_current_3d_view("CENTER", "BOTTOM", offset = (0, 130)),
                location_type = "CUSTOM",
                stay_time = 2,
                fadeout_time = 0.8)
                
        return {"FINISHED"}
    
    def parameter_getter(self):
        return self.auto_smooth_angle, self.segment_amount, self.bevelwidth, self.op_detail, self.op_tag, self.text,

    def execute(self, context):
        c_step_active_object(context.active_object,
            self.modifier_types)

        update_bevel_modifier_if_necessary(
            context.active_object,
            self.segment_amount, 
            self.bevelwidth,
            self.profile_value)

        object = bpy.context.active_object
        object.hops.status = "CSTEP"
            
        try: self.wake_up_overlay()
        except: pass
    
        return {"FINISHED"}
    

def c_step_active_object(object, modifier_types):
    with ExecutionContext(mode = "OBJECT", active_object = object):
        apply_modifiers(object, ignored_types = modifier_types)

    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.reveal()
    bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='EDGE')
    bpy.ops.mesh.select_all(action='DESELECT')
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.transform.edge_bevelweight(value=-1)
    bpy.ops.transform.edge_crease(value=-1)
    bpy.ops.mesh.select_all(action='DESELECT')
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.hide()
    bpy.ops.object.editmode_toggle()
    
    object = bpy.context.active_object
    object.hops.status = "CSTEP"                                  
    
def draw(display, parameter_getter):
    #sharpness, auto_smooth_angle, additive_mode, sub_d_sharpening, segment_amount, bevelwidth = parameter_getter()
    auto_smooth_angle, segment_amount, bevelwidth, op_detail, op_tag, text = parameter_getter()    
        
    scale_factor = 0.9

    glEnable(GL_BLEND)
    glEnable(GL_LINE_SMOOTH)

    set_drawing_dpi(display.get_dpi() * scale_factor)
    dpi_factor = display.get_dpi_factor() * scale_factor
    line_height = 18 * dpi_factor

    transparency = display.transparency
    color = (1, 1, 1, 0.5 * transparency)


    # First Part
    ########################################################

    location = display.location
    x, y = location.x, location.y

    draw_text("Segment Amount:", x, y,
              align = "RIGHT", size = 12, color = color)

    draw_text(format(segment_amount), x + 30 * dpi_factor, y,
              align = "RIGHT", size = 12, color = color)

    draw_text("Auto_Smooth Angle:", x, y - line_height,
              align = "RIGHT", size = 12, color = color)

    draw_text("{}°".format(round(degrees(auto_smooth_angle))), x + 30 * dpi_factor, y - line_height,
              align = "RIGHT", size = 12, color = color)

    # Second Part Part
    ########################################################

    location = display.location
    x, y = location.x, location.y
    r = 175

    draw_text("Bevel Segments:", x + r -5, y,
              align = "RIGHT", size = 12, color = color)

    draw_text("{}".format(segment_amount), x + r + 30 * dpi_factor, y,
              align = "RIGHT", size = 12, color = color)

    draw_text("Bevel Width:", x + r -5, y - line_height,
              align = "RIGHT", size = 12, color = color)

    draw_text("{}".format('%.2f'%(bevelwidth)), x + r + 30* dpi_factor, y - line_height,
              align = "RIGHT", size = 12, color = color)


    # Middle
    ########################################################

    x, y = x - 120 * dpi_factor, y - 27 * dpi_factor
    line_length = 270

    line_width = 2 * dpi_factor
    draw_horizontal_line(x,  y, line_length * dpi_factor + 65, color, width = line_width)

    draw_text(text, x, y - 22 * dpi_factor,
              align = "LEFT", size = 16, color = color)

    draw_horizontal_line(x, y - 31 * dpi_factor, line_length * dpi_factor + 65, color, width = line_width)

    draw_text(op_detail, x + line_length * dpi_factor, y - 42 * dpi_factor,
              align = "RIGHT", size = 9, color = color)

    """
    # Last Part
    ########################################################

    x, y = x + 3 * dpi_factor, y - 50 * dpi_factor

    offset = 30 * dpi_factor

    draw_text("ADDITIVE MODE", x + offset, y,
              align = "LEFT", color = color)

    draw_boolean(additive_mode, x, y, size = 11, alpha = transparency)

    draw_text("SUB D SHARPENING", x + offset, y - line_height,
              align = "LEFT", color = color)

    draw_boolean(sub_d_sharpening, x, y - line_height, size = 11, alpha = transparency)
    """

    glDisable(GL_BLEND)
    glDisable(GL_LINE_SMOOTH)