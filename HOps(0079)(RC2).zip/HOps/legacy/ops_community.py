#"author": "Simon Lusenc (50keda)"

import bpy, bmesh, array
from mathutils import Vector


class WeightNormalsCalculator(bpy.types.Operator):
    """Calculate weighted normals for active object."""
    bl_idname = "object.calculate_weighted_normals"
    bl_label = "Weight Normals"

    cache = {}
    """Cache for calculated weighted normals. It stores normals by key: 'vert_index:edge_index'."""

    @staticmethod
    def calc_weighted_normal(bm, vert_index, edge_index):
        """Calculates weighted normal for given combination of vertex and edge index.
        WARNING: There is no safety chec if thoose two belongs together.

        :param bm: bmesh object
        :type bm: bmesh
        :param vert_index: index of the vertex to calculate normal for
        :type vert_index: int
        :param edge_index: index of the edge to use for calculation (vertex has to belong to this edge)
        :returns: Vector
        """
        normal_hash = str(vert_index) + ":" + str(edge_index)

        if normal_hash in WeightNormalsCalculator.cache:
            return WeightNormalsCalculator.cache[normal_hash]

        edge = bm.edges[edge_index]
        vert = bm.verts[vert_index]

        selected_faces = []

        # edge.seam = True
        # edge.select_set(True)

        for f in edge.link_faces:

            if not f.select:

                f.select = True
                selected_faces.append(f)

        # select linked faces of already selected edges
        # until every smooth face around current loop is selected
        more_selected = 1
        while more_selected > 0:

            more_selected = 0
            for edge1 in vert.link_edges:

                if edge1.smooth and edge1.select:

                    for f in edge1.link_faces:

                        if not f.select:

                            f.select = True
                            selected_faces.append(f)

                            more_selected += 1

        # calc areas
        max_area = 0
        areas = {}
        for i, f in enumerate(selected_faces):
            area = f.calc_area()
            areas[i] = area

            if area > max_area:
                max_area = area

        # calc normal
        normal = Vector()
        for i, f in enumerate(selected_faces):
            perc = areas[i] / max_area
            f.normal_update()
            normal += perc * f.normal

            # also unselect all the faces
            f.select = False

        WeightNormalsCalculator.cache[normal_hash] = normal.normalized()

        return normal.normalized()

    @classmethod
    def poll(cls, context):
        return context.object and context.object.mode == "OBJECT" and context.object.type == "MESH"

    def execute(self, context):

        WeightNormalsCalculator.cache = {}

        mesh = context.object.data

        bm = bmesh.new()
        bm.from_mesh(mesh)
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()

        # unselect everything first
        for v in bm.faces:
            v.select = False

        for v in bm.edges:
            v.select = False

        for v in bm.verts:
            v.select = False

        nor_list = [(0,)] * len(mesh.loops)
        for f in bm.faces:

            # map both edge indices into vertex (loop has info only about one edge)
            verts_edge_map = {}
            for e in f.edges:
                for v in e.verts:

                    v_i = v.index

                    if v_i not in verts_edge_map:
                        verts_edge_map[v_i] = {e.index: 1}
                    else:
                        verts_edge_map[v_i][e.index] = 1

            for curr_loop in f.loops:

                edge_keys = verts_edge_map[curr_loop.vert.index].keys()

                # if current loop vertex has at leas one sharp edge around calculate weighted normal
                for e_i in edge_keys:

                    if not mesh.edges[e_i].use_edge_sharp:

                        curr_n = WeightNormalsCalculator.calc_weighted_normal(bm, curr_loop.vert.index, e_i)
                        nor_list[curr_loop.index] = curr_n

                        break

                else:

                    nor_list[curr_loop.index] = mesh.loops[curr_loop.index].normal

        bm.free()

        mesh.use_auto_smooth = True
        bpy.ops.mesh.customdata_custom_splitnormals_clear()

        bpy.ops.mesh.customdata_custom_splitnormals_add()
        mesh.normals_split_custom_set(nor_list)
        mesh.free_normals_split()

        return {'FINISHED'}
    

import bpy
import bmesh
import mathutils


# addon information
bl_info = {
    "name": "Masked Soften/Harden Normals",
    "author": "Andrew Palmer",
    "version": (0, 0, 3),
    "blender": (2, 75, 0),
    "location": "",
    "description": "Soften/Harden the vertex normals of a mesh using the current selection as a mask that defines which normals are affected.",
    "category": "Mesh"
}


# OPERATES IN OBJECT MODE ONLY
def set_smooth_normals(mesh_data, vertex_indices, vertex_normals):
    """Write smooth vertex normals to the user normal data (mesh loops)."""

    me = mesh_data
    me.calc_normals_split()
    
    # create a structure that matches the required input of the normals_split_custom_set function
    clnors = [mathutils.Vector()] * len(me.loops)

    for loop in me.loops:
        vertex_normal = loop.normal
        vertex_index = loop.vertex_index

        if vertex_index in vertex_indices:
            idx = vertex_indices.index(vertex_index)
            vertex_normal = vertex_normals[idx]
        clnors[loop.index] = vertex_normal

    me.normals_split_custom_set(clnors)


# OPERATES IN OBJECT MODE ONLY
def flip_normals(mesh_data):
    me = mesh_data

    me.calc_normals_split()
    clnors = [mathutils.Vector(loop.normal) for loop in me.loops]

    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.flip_normals()
    bpy.ops.object.mode_set(mode='OBJECT')

    for p in me.polygons:
        if p.select:
            # flip the normals of the selected polygon
            ls = p.loop_start
            le = ls + p.loop_total
            clnors[ls:le] = [-n for n in clnors[ls:le]]
            # revert winding order :(
            ls = p.loop_start + 1
            le = ls + p.loop_total - 1
            clnors[ls:le] = reversed(clnors[ls:le])

    me.normals_split_custom_set(clnors)


# OPERATES IN EDIT MODE ONLY
def harden_normals(mesh_data):
    """Harden normals based on selected faces"""

    me = mesh_data

    me.calc_normals_split()
    clnors = [loop.normal for loop in me.loops]

    for p in me.polygons:
        if p.select:
            ls = p.loop_start
            le = ls + p.loop_total
            clnors[ls:le] = list([p.normal] * p.loop_total)

    me.normals_split_custom_set(clnors)


# OPERATES IN EDIT MODE ONLY
def set_specific_normal_vector(mesh_data, normal):
    """Set the selected normals to a specific direction vector"""

    me = mesh_data

    me.calc_normals_split()
    clnors = [loop.normal for loop in me.loops]

    n = normal.normalized()

    for p in me.polygons:
        if p.select:
            ls = p.loop_start
            le = ls + p.loop_total
            clnors[ls:le] = list([normal] * p.loop_total)

    me.normals_split_custom_set(clnors)


# OPERATES IN EDIT MODE ONLY
def get_smoothed_vertex_normals(mesh_data, smooth_mode="face"):
    """Smooth normals based on selection"""

    bm = bmesh.from_edit_mesh(mesh_data)

    vertex_indices = []
    vertex_normals = []

    selected_verts = [v for v in bm.verts if v.select]

    for v in selected_verts:
        if smooth_mode == "face":
            # smooth based only on selected faces
            ls_faces = [f for f in v.link_faces if f.select] 
        elif smooth_mode == "edge":
            # smooth based on faces linked to selected edges
            ls_edges = [e for e in v.link_edges if e.select]
            ls_faces = []
            for e in ls_edges:
                ls_faces.extend(e.link_faces)
        else:
            # smooth based on all neighboring faces
            ls_faces = [f for f in v.link_faces]

        # set vertex normal to average of face normals
        if len(ls_faces) > 0:
            sum_normal = mathutils.Vector()
            for f in ls_faces:
                sum_normal += f.normal
            vertex_indices.append(v.index)
            vertex_normal = sum_normal / len(ls_faces)
            vertex_normal.normalize()
            vertex_normals.append(vertex_normal)

    return {'vertex_indices': vertex_indices, 'vertex_normals': vertex_normals}


class MaskedSoftenNormals(bpy.types.Operator):
    """Smooth custom normals based on selection"""
    bl_idname = "mesh.masked_soften_normals"
    bl_label = "Masked Soften Normals"
    bl_options = {'REGISTER', 'UNDO'}

    always_use_face_mask = bpy.props.BoolProperty(
        name = "only use faces",
        default = False,
        subtype = 'NONE',
        description = "Only mask using selected faces regardless of the current selection mode"
        )

    def execute(self, context):
        mesh_data = context.object.data
        mesh_data.use_auto_smooth = True

        # get selection mode (VERT, EDGE, FACE)
        select_mode = context.tool_settings.mesh_select_mode
        if select_mode[2] or self.always_use_face_mask:
            vn = get_smoothed_vertex_normals(mesh_data, "face")
        elif select_mode[1]:
            vn = get_smoothed_vertex_normals(mesh_data, "edge")
        else:
            vn = get_smoothed_vertex_normals(mesh_data, "vertex")

        bpy.ops.object.mode_set(mode="OBJECT")
        set_smooth_normals(mesh_data, vn['vertex_indices'], vn['vertex_normals'])
        bpy.ops.object.mode_set(mode="EDIT")

        return {'FINISHED'}

    @classmethod  
    def poll(cls, context):  
        obj = context.object  
        return obj is not None and obj.mode == 'EDIT' 


# TODO: Make a harden normals tool that works in the same way as smooth normals
class MaskedHardenNormals(bpy.types.Operator):
    """Harden custom normals based on selection"""
    bl_idname = "mesh.masked_harden_normals"
    bl_label = "Masked Harden Normals"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        mesh_data = context.object.data
        mesh_data.use_auto_smooth = True

        bpy.ops.object.mode_set(mode="OBJECT")
        harden_normals(mesh_data)
        bpy.ops.object.mode_set(mode="EDIT")

        return {'FINISHED'}

    @classmethod  
    def poll(cls, context):  
        obj = context.object  
        return obj is not None and obj.mode == 'EDIT' 


class FlipCustomNormals(bpy.types.Operator):
    """Flip active mesh's normals, including custom ones"""
    bl_idname = "mesh.masked_flip_custom_normals"
    bl_label = "Flip Custom Normals"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.object  
        return obj is not None and obj.mode == 'EDIT' 

    def execute(self, context):
        mesh_data = context.object.data
        mesh_data.use_auto_smooth = True

        bpy.ops.object.mode_set(mode='OBJECT')
        flip_normals(mesh_data)
        bpy.ops.object.mode_set(mode='EDIT')

        return {'FINISHED'}


class SetSpecificNormalVector(bpy.types.Operator):
    """Precisely set the normals of selected vertices"""
    bl_idname = "mesh.set_specific_custom_normal"
    bl_label = "Set Specific Custom Normals"
    bl_options = {'REGISTER','UNDO'}

    custom_normal = bpy.props.FloatVectorProperty(
        name = "vertex normal",
        default = (0.0,0.0,1.0),
        subtype = 'DIRECTION',
        description = "Value to set selected vertex normals to"
        )

    @classmethod
    def poll(cls, context):
        obj = context.object  
        return obj is not None and obj.mode == 'EDIT' 

    def execute(self, context):
        mesh_data = context.object.data
        mesh_data.use_auto_smooth = True

        bpy.ops.object.mode_set(mode='OBJECT')
        set_specific_normal_vector(mesh_data, self.custom_normal)
        bpy.ops.object.mode_set(mode='EDIT')

        return {'FINISHED'}


class SoftenHardenNormalsPanel(bpy.types.Panel):
    """COMMENT"""
    bl_space_type = "VIEW_3D"
    bl_region_type = "TOOLS"
    bl_context = "mesh_edit"
    bl_category = "Shading / UVs"
    bl_label = "Custom Normals"

    def draw(self, context):
        layout = self.layout

        obj = context.object
        row = layout.row(align=True)
        row.operator("mesh.masked_soften_normals", text="Soften")
        row.operator("mesh.masked_harden_normals", text="Harden")
        row = layout.row(align=True)
        row.operator("mesh.masked_flip_custom_normals", text="Flip Direction")
        row = layout.row(align=True)
        row.prop
        row.operator("mesh.set_specific_custom_normal", text="Set Normals")