#import bpy
#import addon_utils

#def main(context):
#    for ob in context.scene.objects:
        #print(ob)
#        addon_utils.check("weighted_normals.py")


#class AddoncheckOperator(bpy.types.Operator):
#    """Checks For Addon In Particular"""
#    bl_idname = "addon.check_operator"
#    bl_label = "Simple Addon Checker"

#    @classmethod
    #def poll(cls, context):
    #    return context.active_object is not None

    #def execute(self, context):
#    def execute(self):
#        addon_utils.check("weighted_normals.py")
        #main(context)
#        return {'FINISHED'}

