import bpy
import os
from bgl import *
from bpy.props import *
from math import radians, degrees
from ... utils.context import ExecutionContext
from ... preferences import tool_overlays_enabled
from ... overlay_drawer import show_text_overlay
from ... utils.blender_ui import get_location_in_current_3d_view
from .. utils import clear_ssharps, mark_ssharps, set_smoothing
from ... overlay_drawer import show_custom_overlay, disable_active_overlays
from ... graphics.drawing2d import set_drawing_dpi, draw_horizontal_line, draw_boolean, draw_text
from ... overlay_drawer import show_text_overlay

class symmetrizeMesh(bpy.types.Operator):
    bl_idname = "view3d.symmetrize"
    bl_label = "Symmetrize Mesh"
    bl_description = "Mesh Symmetrize"
    bl_options = {"REGISTER","UNDO"}

    type = "Default"

    is_cstep = BoolProperty(name = "Is Cstep Mesh",
                              description = "Hide Mesh If Cstep",
                              default = True)

    symmetryTypeItems = [
        ("NEGATIVE_X", "-X", ""),
        ("POSITIVE_X",  "X", ""),
        ("NEGATIVE_Y", "-Y", ""),
        ("POSITIVE_Y",  "Y", ""),
        ("NEGATIVE_Z", "-Z", ""),
        ("POSITIVE_Z",  "Z", ""),
        ]

    symtype = EnumProperty( name = "Symmetry Axis",
                            items = symmetryTypeItems,
                            description = "Axis For Symmetrize",
                            default = "NEGATIVE_X")

    @classmethod
    def poll(cls, context):
        return getattr(context.active_object, "type", "") == "MESH"

    def draw(self, context):
        layout = self.layout

        layout.prop(self, "symtype")

    def invoke(self, context, event):
        self.execute(context)

        if tool_overlays_enabled():
            disable_active_overlays()
            self.wake_up_overlay = show_custom_overlay(draw,
                parameter_getter = self.parameter_getter,
                location = get_location_in_current_3d_view("CENTER", "BOTTOM", offset = (0, 130)),
                location_type = "CUSTOM",
                stay_time = 2,
                fadeout_time = 0.8)

            message = "Mesh Hidden"
            show_text_overlay(text = message, font_size = 10, color = (1, 1, 1),
                          stay_time = 1, fadeout_time = 1)
        return {"FINISHED"}

    def parameter_getter(self):
        return self.type, self.symtype, self.is_cstep

    def execute(self, context):
        object = bpy.context.active_object
        self.type = object.hops.status

        setup_mesh(object)
        sym_mesh(object, self.symtype)

        if self.type == "CSTEP":
            cstep_reset(object)
            self.is_cstep = True
        else:     
            self.is_cstep = False
        
        try: self.wake_up_overlay()
        except: pass

        return {"FINISHED"}

def setup_mesh(object):
    object = bpy.context.active_object
    bpy.ops.object.editmode_toggle()
    bpy.ops.mesh.reveal()
    bpy.ops.mesh.select_all(action='DESELECT')
    bpy.ops.mesh.select_all(action='TOGGLE')

def sym_mesh(object,symtype):
    bpy.ops.mesh.symmetrize(direction = symtype)
    bpy.ops.object.editmode_toggle()

def cstep_reset(object):
    object = bpy.context.active_object
    bpy.ops.object.editmode_toggle()
    bpy.ops.mesh.select_all(action='DESELECT')
    bpy.ops.mesh.select_all(action='TOGGLE')
    bpy.ops.mesh.hide(unselected=False)
    bpy.ops.object.editmode_toggle()


# Overlay
###################################################################

def draw(display, parameter_getter):
    type, symtype, is_cstep = parameter_getter()
    scale_factor = 0.9

    glEnable(GL_BLEND)
    glEnable(GL_LINE_SMOOTH)

    set_drawing_dpi(display.get_dpi() * scale_factor)
    dpi_factor = display.get_dpi_factor() * scale_factor
    line_height = 18 * dpi_factor

    transparency = display.transparency
    color = (1, 1, 1, 0.5 * transparency)
    if "NEGATIVE" in symtype:
        color2 = (1, 0, 0, 0.5 * transparency)
    else:
        color2 = (0, 1, 0, 0.5 * transparency)

    # First Part
    ########################################################

    location = display.location
    x, y = location.x, location.y

    draw_text("MESH STATUS", x - 20, y,
              align = "RIGHT", size = 12, color = color)

    draw_text(type, x + 30 + 120 * dpi_factor, y,
              align = "RIGHT", size = 12, color = color)

    draw_text("SYMMETRY AXIS:", x - 20, y - line_height,
              align = "RIGHT", size = 12, color = color)

    draw_text(symtype, x + 30 + 120 * dpi_factor, y - line_height,
              align = "RIGHT", size = 12, color = color2)


    # Middle
    ########################################################

    x, y = x - 120 * dpi_factor, y - 27 * dpi_factor
    line_length = 270

    line_width = 2 * dpi_factor
    draw_horizontal_line(x,  y, line_length * dpi_factor, color, width = line_width)

    draw_text("SYMMETRIZE", x, y - 22 * dpi_factor,
              align = "LEFT", size = 16, color = color)

    draw_horizontal_line(x, y - 31 * dpi_factor, line_length * dpi_factor, color, width = line_width)

    draw_text("SYMMETIZE COMPLETE", x + line_length * dpi_factor, y - 42 * dpi_factor,
              align = "RIGHT", size = 9, color = color)


    # Last Part
    ########################################################

    x, y = x + 3 * dpi_factor, y - 50 * dpi_factor

    offset = 30 * dpi_factor

    if type == "CSTEP":
        draw_text("CSTEP Edit Mode Hiding", x + offset, y - line_height,
                  align = "LEFT", color = color)

        draw_boolean(is_cstep, x, y - line_height, size = 11, alpha = transparency)
    else:
        draw_text(type, x + offset - 30, y - line_height + 15,
                  align = "LEFT", size = 16, color = color2)
        
    
    glDisable(GL_BLEND)
    glDisable(GL_LINE_SMOOTH)
