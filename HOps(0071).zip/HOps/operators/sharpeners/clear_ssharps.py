import os
import bpy
import bmesh
from bgl import *
from bpy.props import *
from bpy.props import *
import bpy.utils.previews
from random import choice
from math import pi, radians
from math import radians, degrees
from ... preferences import tool_overlays_enabled
from ... utils.blender_ui import get_location_in_current_3d_view
from ... overlay_drawer import show_custom_overlay, disable_active_overlays
from ... graphics.drawing2d import set_drawing_dpi, draw_horizontal_line, draw_boolean, draw_text

#_____________________________________________________________clear ssharps (OBJECT MODE)________________________
class un_sharpOperator(bpy.types.Operator):
    '''Clear Off Sharps And Bevels In Object Mode'''
    bl_idname = "clean.sharps"
    bl_label = "Remove Ssharps"
    bl_options = {'REGISTER', 'UNDO'}

    removeMods = BoolProperty(default = True)
    clearsharps = BoolProperty(default = True)
    clearbevel = BoolProperty(default = True)
    clearcrease = BoolProperty(default = True)

    text = "SSharps Removed"
    op_tag = "Clean Ssharp"
    op_detail = "Selected Ssharps Removed"

    @classmethod
    def poll(cls, context):
        return getattr(context.active_object, "type", "") == "MESH"

    def draw(self, context):
        layout = self.layout

        box = layout.box()
        # DRAW YOUR PROPERTIES IN A BOX
        box.prop( self, 'removeMods', text = "RemoveModifiers?")
        box.prop( self, 'clearsharps', text = "Clear Sharps")
        box.prop( self, 'clearbevel', text = "Clear Bevels")
        box.prop( self, 'clearcrease', text = "Clear Crease")

    def invoke(self, context, event):
        self.execute(context)

        if tool_overlays_enabled():
            disable_active_overlays()
            self.wake_up_overlay = show_custom_overlay(draw_clearsharps,
                parameter_getter = self.parameter_getter,
                location = get_location_in_current_3d_view("CENTER", "BOTTOM", offset = (0, 130)),
                location_type = "CUSTOM",
                stay_time = 1,
                fadeout_time = 0.8)

        return {"FINISHED"}

    def parameter_getter(self):
        return self.clearsharps, self.clearbevel, self.clearcrease, self.op_tag, self.op_detail

    def execute(self, context):
        clear_ssharps_active_object(
            self.removeMods,
            self.clearsharps,
            self.clearbevel,
            self.clearcrease,
            self.text)

        try: self.wake_up_overlay()
        except: pass

        return {'FINISHED'}



#_____________________________________________________________clear ssharps________________________
def clear_ssharps_active_object(removeMods, clearsharps, clearbevel, clearcrease, text):
    remove_mods_shadeflat(removeMods)
    clear_sharps(clearsharps,
                clearbevel,
                clearcrease)
    #show_message(text)
    object = bpy.context.active_object
    object.hops.status = "UNDEFINED"




def clear_sharps(clearsharps, clearbevel, clearcrease):
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.reveal()
    bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='EDGE')

    if clearsharps == True:
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.mesh.select_all(action='TOGGLE')

        bpy.ops.mesh.mark_sharp(clear=True)
    if clearbevel == True:
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.mesh.select_all(action='TOGGLE')
        bpy.ops.transform.edge_bevelweight(value=-1)
    if clearcrease == True:
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.mesh.select_all(action='TOGGLE')

        bpy.ops.transform.edge_crease(value=-1)
    bpy.ops.object.editmode_toggle()

def remove_mods_shadeflat(removeMods):
    if removeMods:
        bpy.ops.object.modifier_remove(modifier="Bevel")
        bpy.ops.object.modifier_remove(modifier="Solidify")

    else:
        bpy.context.object.modifiers["Bevel"].limit_method = 'ANGLE'
        bpy.context.object.modifiers["Bevel"].angle_limit = 0.7

def show_message(text):
    pass

def draw_clearsharps(display, parameter_getter):
    clearsharps, clearbevel, clearcrease, op_detail, op_tag = parameter_getter()
    scale_factor = 0.9

    glEnable(GL_BLEND)
    glEnable(GL_LINE_SMOOTH)

    set_drawing_dpi(display.get_dpi() * scale_factor)
    dpi_factor = display.get_dpi_factor() * scale_factor
    line_height = 18 * dpi_factor

    transparency = display.transparency
    color = (1, 1, 1, 0.5)

     # First Part
    ########################################################

    location = display.location
    x, y = location.x, location.y

    draw_text("Selected SSharps Removed", x, y - line_height,
              align = "LEFT", size = 10, color = color)

    # Middle
    ########################################################

    x, y = x - 120 * dpi_factor, y - 27 * dpi_factor
    line_length = 270

    line_width = 2 * dpi_factor
    draw_horizontal_line(x,  y, line_length * dpi_factor, color, width = line_width)

    draw_text(op_tag, x, y - 22 * dpi_factor,
              align = "LEFT", size = 16, color = color)

    draw_horizontal_line(x, y - 31 * dpi_factor, line_length * dpi_factor, color, width = line_width)

    draw_text(op_detail, x + line_length * dpi_factor, y - 42 * dpi_factor,
              align = "RIGHT", size = 9, color = color)


    # Last Part
    ########################################################

    x, y = x + 3 * dpi_factor, y - 50 * dpi_factor

    offset = 30 * dpi_factor

    draw_text("Clear Sharps", x + offset, y,
              align = "LEFT", color = color)

    draw_boolean(clearsharps, x, y, size = 11, alpha = transparency)

    draw_text("Clear Bevelweight", x + offset, y - line_height,
              align = "LEFT", color = color)

    draw_boolean(clearbevel, x, y - line_height, size = 11, alpha = transparency)

    draw_text("Clear Crease", x + offset, y - line_height -20,
              align = "LEFT", color = color)

    draw_boolean(clearcrease, x, y - line_height -20, size = 11, alpha = transparency)

    glDisable(GL_BLEND)
    glDisable(GL_LINE_SMOOTH)
