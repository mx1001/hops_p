import os
import bpy
import bmesh
from bpy.props import *
from math import pi, radians
import bpy.utils.previews
from random import choice

#### Symetrize X ####
class Symetrize_X_POSITIVE(bpy.types.Operator):  
    bl_idname = "symetrize.xpositive"  
    bl_label = "Symetrize X Positive"  
    bl_options = {'REGISTER', 'UNDO'}
  
    def execute(self, context):
        
        bpy.ops.object.mode_set(mode = 'OBJECT')
        bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
        bpy.ops.object.mode_set(mode = 'EDIT')
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.mesh.select_all(action='TOGGLE')
        bpy.ops.mesh.symmetrize(direction='POSITIVE_X')
        bpy.ops.mesh.select_all(action='TOGGLE')
        return {'FINISHED'} 

class Symetrize_X_NEGATIVE(bpy.types.Operator):  
    bl_idname = "symetrize.xnegative"  
    bl_label = "Symetrize X Negative"  
    bl_options = {'REGISTER', 'UNDO'}
  
    def execute(self, context):
        
        bpy.ops.object.mode_set(mode = 'OBJECT')
        bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
        bpy.ops.object.mode_set(mode = 'EDIT')
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.mesh.select_all(action='TOGGLE')
        bpy.ops.mesh.symmetrize(direction='NEGATIVE_X')
        bpy.ops.mesh.select_all(action='TOGGLE')
        return {'FINISHED'} 

#### Symetrize Y ####
class Symetrize_Y_POSITIVE(bpy.types.Operator):  
    bl_idname = "symetrize.ypositive"  
    bl_label = "Symetrize Y Positive"  
    bl_options = {'REGISTER', 'UNDO'}
  
    def execute(self, context):
        
        bpy.ops.object.mode_set(mode = 'OBJECT')
        bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
        bpy.ops.object.mode_set(mode = 'EDIT')
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.mesh.select_all(action='TOGGLE')
        bpy.ops.mesh.symmetrize(direction='POSITIVE_Y')
        bpy.ops.mesh.select_all(action='TOGGLE')
        return {'FINISHED'} 


class Symetrize_Y_NEGATIVE(bpy.types.Operator):  
    bl_idname = "symetrize.ynegative"  
    bl_label = "Symetrize Y Negative"  
    bl_options = {'REGISTER', 'UNDO'}
  
    def execute(self, context):
        
        bpy.ops.object.mode_set(mode = 'OBJECT')
        bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
        bpy.ops.object.mode_set(mode = 'EDIT')
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.mesh.select_all(action='TOGGLE')
        bpy.ops.mesh.symmetrize(direction='NEGATIVE_Y')
        bpy.ops.mesh.select_all(action='TOGGLE')
        return {'FINISHED'}     

#### Symetrize Z ####
class Symetrize_Z_POSITIVE(bpy.types.Operator):  
    bl_idname = "symetrize.zpositive"  
    bl_label = "Symetrize Z Positive"  
    bl_options = {'REGISTER', 'UNDO'}
  
    def execute(self, context):
        
        bpy.ops.object.mode_set(mode = 'OBJECT')
        bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
        bpy.ops.object.mode_set(mode = 'EDIT')
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.mesh.select_all(action='TOGGLE')
        bpy.ops.mesh.symmetrize(direction='POSITIVE_Z')
        bpy.ops.mesh.select_all(action='TOGGLE')
        return {'FINISHED'} 

class Symetrize_Z_NEGATIVE(bpy.types.Operator):  
    bl_idname = "symetrize.znegative"  
    bl_label = "Symetrize Z Negative"  
    bl_options = {'REGISTER', 'UNDO'}
  
    def execute(self, context):
        
        bpy.ops.object.mode_set(mode = 'OBJECT')
        bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
        bpy.ops.object.mode_set(mode = 'EDIT')
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.mesh.select_all(action='TOGGLE')
        bpy.ops.mesh.symmetrize(direction='NEGATIVE_Z')
        bpy.ops.mesh.select_all(action='TOGGLE')
        return {'FINISHED'}     

#############################
#AutoMirroring-X Operators Start Here
#############################

#half stomps in edit mode
class ehalfStomp(bpy.types.Operator):
    "Symmetrizes Based Off Of Right"
    bl_idname = "ehalfslap.object"
    bl_label = "ehalfslapObject"
    bl_options = {'REGISTER', 'UNDO'} 
    #mirrors on the X
    
    reverse = BoolProperty(default = False)
        
    def execute(self, context):
        #bpy.ops.object.editmode_toggle()        
             
        if self.reverse:
            #bpy.ops.object.editmode_toggle()
            bpy.ops.mesh.reveal()
            bpy.ops.mesh.select_all(action='DESELECT')
            bpy.ops.mesh.select_all(action='TOGGLE')
            bpy.ops.mesh.symmetrize(direction='POSITIVE_X')
            bpy.ops.object.editmode_toggle()        
        else:
            #bpy.ops.object.editmode_toggle()
            bpy.ops.mesh.reveal()
            bpy.ops.mesh.select_all(action='DESELECT')
            bpy.ops.mesh.select_all(action='TOGGLE')
            bpy.ops.mesh.symmetrize(direction='NEGATIVE_X')
            bpy.ops.object.editmode_toggle()
            
        return {'FINISHED'}

#half stomps in object mode
class halfStomp(bpy.types.Operator):
    "Symmetrizes Based Off Of Right"
    bl_idname = "halfslap.object"
    bl_label = "halfslapObject"
    bl_options = {'REGISTER', 'UNDO'}
    
    reverse = BoolProperty(default = False)
    
    def execute(self, context):
         #additions
        is_bevel_3 = False

        for mode in bpy.context.object.modifiers :
            if mode.type == "BEVEL":
                if mode.profile > 0.70 and mode.profile < 0.72:
                    is_bevel_3 = True
        #end additions  
            
        if self.reverse:
            bpy.ops.object.editmode_toggle()
            bpy.ops.mesh.reveal()
            bpy.ops.mesh.select_all(action='DESELECT')
            bpy.ops.mesh.select_all(action='TOGGLE')
            bpy.ops.mesh.symmetrize(direction='POSITIVE_X')
            #bpy.ops.object.editmode_toggle()
            if is_bevel_3 == True:
                #bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.mesh.reveal()
                bpy.ops.mesh.select_all(action='DESELECT')
                bpy.ops.mesh.select_all(action='TOGGLE')
                bpy.ops.mesh.hide(unselected=False)
            bpy.ops.object.editmode_toggle()
        
        else:
            bpy.ops.object.editmode_toggle()
            bpy.ops.mesh.reveal()
            bpy.ops.mesh.select_all(action='DESELECT')
            bpy.ops.mesh.select_all(action='TOGGLE')
            bpy.ops.mesh.symmetrize(direction='NEGATIVE_X')
            #bpy.ops.object.editmode_toggle()
            if is_bevel_3 == True:
                #bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.mesh.reveal()
                bpy.ops.mesh.select_all(action='DESELECT')
                bpy.ops.mesh.select_all(action='TOGGLE')
                bpy.ops.mesh.hide(unselected=False)
            bpy.ops.object.editmode_toggle()
            
        return {'FINISHED'}
    
#half stomps in object mode
class yhalfStomp(bpy.types.Operator):
    "Symmetrizes Based Off Of Right"
    bl_idname = "yhalfslap.object"
    bl_label = "yhalfslapObject"
    bl_options = {'REGISTER', 'UNDO'}
    
    reverse = BoolProperty(default = False)
    
    def execute(self, context):
        #additions
        is_bevel = False
        is_bool = False
        is_bevel_3 = False
        is_solidify = False
        is_multiselected = False
        is_notselected = False
        is_noactiveobject = False
        multislist = bpy.context.selected_objects
        activeobject = bpy.context.scene.objects.active
        is_formerge = False

        if len(multislist) > 1:
            is_multiselected = True
        if len(multislist) < 1:
            is_notselected = True
        if activeobject == None:
            is_noactiveobject = True

        for obj in bpy.context.selected_objects:
            if obj.name.startswith("AP"):
                is_formerge = True
                pass

        for mode in bpy.context.object.modifiers :
            if mode.type == 'BEVEL' :
                is_bevel = True
            if mode.type == "BEVEL":
                if mode.profile > 0.70 and mode.profile < 0.72:
                    is_bevel_3 = True
            if mode.type == 'BOOLEAN' :
                is_bool = True
            if mode.type == 'SOLIDIFY':
                is_solidify = True
        #end additions  
        
        if self.reverse:
            bpy.ops.object.editmode_toggle()
            bpy.ops.mesh.reveal()
            bpy.ops.mesh.select_all(action='DESELECT')
            bpy.ops.mesh.select_all(action='TOGGLE')
            bpy.ops.mesh.symmetrize(direction='POSITIVE_Y')
            #bpy.ops.object.editmode_toggle()
            if is_bevel_3 == True:
                #bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.mesh.reveal()
                bpy.ops.mesh.select_all(action='DESELECT')
                bpy.ops.mesh.select_all(action='TOGGLE')
                bpy.ops.mesh.hide(unselected=False)
            bpy.ops.object.editmode_toggle()
        
        else:
            bpy.ops.object.editmode_toggle()
            bpy.ops.mesh.reveal()
            bpy.ops.mesh.select_all(action='DESELECT')
            bpy.ops.mesh.select_all(action='TOGGLE')
            bpy.ops.mesh.symmetrize(direction='NEGATIVE_Y')
            #bpy.ops.object.editmode_toggle()
            if is_bevel_3 == True:
                #bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.mesh.reveal()
                bpy.ops.mesh.select_all(action='DESELECT')
                bpy.ops.mesh.select_all(action='TOGGLE')
                bpy.ops.mesh.hide(unselected=False)
            bpy.ops.object.editmode_toggle()
            
        return {'FINISHED'}

# Z
class zhalfStomp(bpy.types.Operator):
    "Symmetrizes Based Off Of Right"
    bl_idname = "zhalfslap.object"
    bl_label = "zhalfslapObject"
    bl_options = {'REGISTER', 'UNDO'}
    
    reverse = BoolProperty(default = False)
    
    
    def execute(self, context):
        #additions
        is_bevel_3 = False

        for mode in bpy.context.object.modifiers :
            if mode.type == "BEVEL":
                if mode.profile > 0.70 and mode.profile < 0.72:
                    is_bevel_3 = True
        #end additions  
        
        if self.reverse:
            bpy.ops.object.editmode_toggle()
            bpy.ops.mesh.reveal()
            bpy.ops.mesh.select_all(action='DESELECT')
            bpy.ops.mesh.select_all(action='TOGGLE')
            bpy.ops.mesh.symmetrize(direction='POSITIVE_Z')
            #bpy.ops.object.editmode_toggle()
            if is_bevel_3 == True:
                #bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.mesh.reveal()
                bpy.ops.mesh.select_all(action='DESELECT')
                bpy.ops.mesh.select_all(action='TOGGLE')
                bpy.ops.mesh.hide(unselected=False)
            bpy.ops.object.editmode_toggle()
        
        else:
            bpy.ops.object.editmode_toggle()
            bpy.ops.mesh.reveal()
            bpy.ops.mesh.select_all(action='DESELECT')
            bpy.ops.mesh.select_all(action='TOGGLE')
            bpy.ops.mesh.symmetrize(direction='NEGATIVE_Z')
            #bpy.ops.object.editmode_toggle()
            if is_bevel_3 == True:
                #bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.mesh.reveal()
                bpy.ops.mesh.select_all(action='DESELECT')
                bpy.ops.mesh.select_all(action='TOGGLE')
                bpy.ops.mesh.hide(unselected=False)
            bpy.ops.object.editmode_toggle()
            
        return {'FINISHED'}
    