import os
import bpy
import bmesh
from bpy.props import *
from math import pi, radians
import bpy.utils.previews
from random import choice

#############################
#Pawel Lyczkowski's Hard UVs 
#############################

class RUnwrap(bpy.types.Operator):
        '''Tooltip'''
        bl_description = "Loops through selected objects, marks sharp and seams on sharp edges, and unwraps. Works best with hardsurface models."
        bl_idname = "object.runwrap"
        bl_label = "RUnwrap"
        bl_options = {'REGISTER', 'UNDO'}
 
        rsharpness = bpy.props.FloatProperty(name="Island Size", default=1)
        """@classmethod
        def poll(cls, context):
                obj = bpy.context.selected_objects
                obj_type = obj.type
                # return(obj and obj_type in {'MESH', 'CURVE', 'SURFACE', 'ARMATURE', 'FONT', 'LATTICE'} and context.mode == 'OBJECT')
                return(obj in {'MESH'})"""
 
        def execute(self, context):

            bpy.ops.mesh.bb_doublelatch()
            mesh_bb = bpy.context.active_object
            bpy.context.object.show_wire = True
            bpy.context.object.draw_type = 'BOUNDS'

            bpy.ops.mesh.ob_doublelatch()
            mesh_ob = bpy.context.active_object

            bpy.ops.mesh.ap_doublelatch()
            mesh_ap = bpy.context.active_object
            bpy.context.object.show_wire = True
            bpy.context.object.draw_type = 'BOUNDS'

            bpy.ops.object.select_all(action='DESELECT')

            mesh_ob.select = True
            mesh_bb.select = True
            mesh_ap.select = True

            bpy.ops.object.parent_set(type='OBJECT', keep_transform=False)

            bpy.ops.object.select_all(action='DESELECT')

            mesh_ap.select = True


            
            return {'FINISHED'}
 

#############################
# C Unwrap 
#############################


class CUnwrap(bpy.types.Operator):
        '''Tooltip'''
        bl_description = "Loops through selected objects, marks sharp and seams on sharp edges, and cnwraps. Works best with hardsurface models."
        bl_idname = "object.cunwrap"
        bl_label = "Cunwrap"
        bl_options = {'REGISTER', 'UNDO'}
 
        rsharpness = bpy.props.FloatProperty(name="Island Size", default=0.523599)
        disolve_edges = BoolProperty(default = False)

        def execute(self, context):
 

                for obj in bpy.context.selected_objects:
                        
                        if self.disolve_edges:
                      
                            bpy.context.scene.objects.active = obj
     
                            bpy.ops.object.mode_set(mode = 'EDIT')
                            bpy.ops.mesh.select_mode(type="EDGE")

                            bpy.ops.mesh.edges_select_sharp(sharpness=self.rsharpness)
                            bpy.ops.mesh.mark_seam(clear=False)
     
                            #bpy.ops.mesh.select_similar(type='SHARP', threshold=0.01)
                            #bpy.ops.mesh.mark_seam(clear=False)

                            bpy.ops.mesh.select_all(action = 'SELECT')
                            bpy.ops.transform.edge_crease(value=1)

                            bpy.ops.mesh.select_all(action = 'DESELECT')

                            bpy.ops.data.facetype_select(select_mode="EDGE", face_type='5')

                            bpy.ops.mesh.quads_convert_to_tris()

                            bpy.ops.mesh.select_all(action = 'SELECT')

                            bpy.ops.uv.smart_project(island_margin=0.02)

                            bpy.ops.mesh.select_all(action = 'DESELECT')

                            bpy.ops.mesh.edges_select_sharp(sharpness=self.rsharpness)
                            bpy.ops.transform.edge_crease(value=1)
                            bpy.ops.mesh.select_similar(type='CREASE', threshold=0.01)

                            bpy.ops.mesh.select_all(action='INVERT')

                            bpy.ops.mesh.dissolve_edges(use_verts=True)
                            
                            bpy.ops.mesh.select_all(action = 'SELECT')
                            bpy.ops.transform.edge_crease(value=-1)
                            bpy.ops.mesh.mark_seam(clear=True)
                                                    
                            bpy.ops.mesh.select_all(action = 'DESELECT')
                            bpy.ops.object.mode_set(mode = 'OBJECT')
                            
                        else:

                            bpy.context.scene.objects.active = obj
     
                            bpy.ops.object.mode_set(mode = 'EDIT')
                            bpy.ops.mesh.select_mode(type="EDGE")

                            bpy.ops.mesh.edges_select_sharp(sharpness=self.rsharpness)
                            bpy.ops.mesh.mark_seam(clear=False)

                            bpy.ops.mesh.select_all(action = 'SELECT')

                            bpy.ops.uv.smart_project(island_margin=0.02)

                            bpy.ops.object.mode_set(mode = 'OBJECT')
 
                return {'FINISHED'}
 