import os
import bpy
import bmesh
from bpy.props import *
from math import pi, radians
import bpy.utils.previews
from random import choice

#############################
#Created A Setup For C/S Step To Hide The Mesh After Operations
#############################
class cssetup(bpy.types.Operator):
    '''Sets Up Mesh For Subsequent Sstepping By Hiding The Mesh'''
    bl_description = "C/S/step-Setup"
    bl_idname = "cssetup.objects"
    bl_label = "cssetup"
    bl_options = {'REGISTER', 'UNDO'}


    def execute(self, context):
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.reveal()
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.mesh.select_all(action='TOGGLE')
        bpy.ops.mesh.hide(unselected=False)
        return {'FINISHED'}

####################################### S STEP
class sstep(bpy.types.Operator):
    '''Sharpen Without Modifiers'''
    bl_description = "sstep "
    bl_idname = "sstep.objects"
    bl_label = "sstep"
    bl_options = {'REGISTER', 'UNDO'}

    items = [(x.identifier, x.name, x.description, x.icon)
             for x in bpy.types.Modifier.bl_rna.properties['type'].enum_items]

    modtypes = EnumProperty(name="Modifier Types",
                           items=[(id, name, desc, icon, 2**i) for i, (id, name, desc, icon) in enumerate(items)
                                   if id in ['BOOLEAN', 'MIRROR', 'BEVEL']],
                           description="Don't apply these",
                           default={'BEVEL', 'MIRROR'},
                           options={'ENUM_FLAG'})

    angle = FloatProperty(name="AutoSmooth Angle",
                          description="Set AutoSmooth angle",
                          default= radians(60.0),
                          min = 0.0,
                          max = radians(180.0),
                          subtype='ANGLE')

    bevelwidth = FloatProperty(name="Bevel Width Amount",
                               description="Set Bevel Width",
                               default=0.0200,
                               min =
                               0.002,
                               max =0.25)

    bevelsegments = IntProperty(name="Bevel Width Amount",
                               description="Set Bevel Segments",
                               default= 3,
                               min = 1,
                               max = 12)

    togglesharpening = BoolProperty(default = True)

    apply_all = BoolProperty(default = True)

    original_bevel = FloatProperty()

    ssharpangle = FloatProperty(name="SSharpening Angle", description="Set SSharp Angle", default= 30.0, min = 0.0, max = 180.0)

    cstepmode = BoolProperty(default = True)

    alternatemode = BoolProperty(default = True)

    # ADD A BOOLEAN PROPERTY TO DISCERN BETWEEN THE TWO ALTERNATE MODES and cstep mode
    @classmethod
    def poll(cls, context):
        ob = context.object
        if ob is None:
            return False
        return (ob.type == 'MESH')

    def draw(self, context):
        #global cstepmode

        layout = self.layout

        box = layout.box()
        col = box.column()
        col.prop(self, "modtypes", expand=True)
        box.prop( self, 'ssharpangle', text = "SsharpAngle" )
        box.prop( self, 'angle', text = "SmoothingAngle" )
        box.prop( self, 'alternatemode', text = "Don't Recalculate")
        box.prop( self, 'bevelsegments', text = "Bevel Segements")

       # AR = cant make it work for global variable
        box.prop( self,'cstepmode', text = "cStep fix")

    #If - Default Calculation / Else - Replacive Calculation
    def execute(self, context):

        scene = context.scene
        ob = context.object  # soapbox call don't use bpy.context as context is passed
        obs = context.selected_objects
        original_bevel = self.original_bevel
        bevelwidth = self.bevelwidth
        angle = self.angle
        #bevelsegments = self.bevelsegments

        ssharpangle = self.ssharpangle
        ssharpangle = ssharpangle * (3.14159265359/180)

        b = bpy.context.active_object



        mod_dic = {}
        if self.apply_all:
        #remove modifiers no one would want applied in this instance

        #bpy.ops.object.modifier_remove(modifier="Bevel")
        #bpy.ops.object.modifier_remove(modifier="Solidify")

        # replace with
            mods = [m for m in ob.modifiers if m.type in self.modtypes]
            for mod in mods:

                mod_dic[mod.name] = {k:getattr(mod, k) for k in mod.bl_rna.properties.keys()
                                 if k not in ["rna_type"]}
                #print(mod_dic)
                ob.modifiers.remove(mod)

        #convert to mesh for sanity
        #bpy.ops.object.convert(target='MESH')
        #Object.to_mesh(scene, apply_modifiers, settings, calc_tessface=True, calc_undeformed=False)

            mesh_name = ob.data.name
            ob.data.name = 'XXXX'
        # remove the old mesh
            if not ob.data.users:
                bpy.data.meshes.remove(ob.data)
            mesh = ob.to_mesh(scene, True, 'PREVIEW') # or 'RENDER'
            ob.modifiers.clear()
            mesh.name = mesh_name
            ob.data = mesh

            for name, settings in mod_dic.items():
                m = ob.modifiers.new(name, settings["type"])
                for s, v in settings.items():
                    if s == "type":
                        continue
                    setattr(m, s, v)
        #Start In Edit Mode
        bpy.ops.object.mode_set(mode='EDIT')

        '''#delete unwanted edges
        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='FACE')
        bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='EDGE')
        bpy.ops.mesh.select_all(action='INVERT')
        bpy.ops.mesh.dissolve_edges()
        bpy.ops.mesh.select_all(action='DESELECT')'''

        #Unhide all The Geo!

        #bpy.ops.mesh.reveal()

        #Now Sharpen It
        bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='EDGE')
        bpy.ops.mesh.select_all(action='DESELECT')

        #Selects Sharps From A Nothing Selection
        bpy.ops.mesh.edges_select_sharp(sharpness=ssharpangle)

        #And Then Adds Weight / Crease / Sharp
        bpy.ops.transform.edge_bevelweight(value=1)
        bpy.ops.transform.edge_crease(value=1)
        bpy.ops.mesh.mark_sharp()

        #try hiding the mesh at the end of sstep
        '''bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.mesh.hide()'''

        #Comes Out Of Edit Mode
        bpy.ops.object.editmode_toggle()
        bpy.ops.object.select_all(action='DESELECT')

        b.select = True

        bpy.context.object.data.auto_smooth_angle = angle
        bpy.ops.object.shade_smooth()
        #bpy.context.object.modifiers["Bevel"].segments = bevelsegments

        """
        text = "\n".join([ "(C)Step Mode_________(S)Step",
                    "Bevels : New Cuts Calculated",
                    "____________________________"])

        """
        text = "(S)Step - New bevels calculated."

        return {'FINISHED'}


#############################
#Adrian's CStep
#############################
class cstepOperator(bpy.types.Operator):
    '''AR's Cstep Idea'''
    bl_idname = "cstep.objects"
    bl_label = "CStep"
    bl_options = {'REGISTER', 'UNDO'}



    items = [(x.identifier, x.name, x.description, x.icon)
             for x in bpy.types.Modifier.bl_rna.properties['type'].enum_items]

    modtypes = EnumProperty(name="Modifier Types",
                           items=[(id, name, desc, icon, 2**i) for i, (id, name, desc, icon) in enumerate(items)
                                   if id in ['BOOLEAN', 'MIRROR']],
                           description="Don't apply these",
                           default={'BOOLEAN', 'MIRROR'},
                           options={'ENUM_FLAG'})

    togglesharpening = BoolProperty(default = True)

    apply_all = BoolProperty(default = True)

    original_bevel = FloatProperty()

    ssharpangle = FloatProperty(name="SSharpening Angle", description="Set SSharp Angle", default= 30.0, min = 0.0, max = 180.0)

    angle = FloatProperty(name="AutoSmooth Angle", description="Set AutoSmooth angle", default= 60.0, min = 0.0, max = 180.0)

    bevelwidth = FloatProperty(name="Bevel Width Amount", description="Set Bevel Width", default= 0.01, min = 0.002, max = 0.25)


    @classmethod
    def poll(cls, context):
        ob = context.object
        if ob is None:
            return False
        return (ob.type == 'MESH')

    def draw(self, context):
        layout = self.layout

        box = layout.box()
        col = box.column()
        col.prop(self, "modtypes", expand=True)

    def execute(self, context):
        #convert angle
        bevelwidth = self.bevelwidth
        #ob = bpy.context.selected_objects
        angle = self.angle
        angle = angle * (3.14159265359/180)
        scene = context.scene
        ob = context.object  # soapbox call don't use bpy.context as context is passed
        obs = context.selected_objects
        original_bevel = self.original_bevel
        ssharpangle = self.ssharpangle
        ssharpangle = ssharpangle * (3.14159265359/180)
        global cstepmode

        mod_dic = {}
        if self.apply_all:
            #remove modifiers no one would want applied in this instance


            # replace with
            mods = [m for m in ob.modifiers if m.type in self.modtypes]
            for mod in mods:

                mod_dic[mod.name] = {k:getattr(mod, k) for k in mod.bl_rna.properties.keys()
                                     if k not in ["rna_type"]}
                #print(mod_dic)
                ob.modifiers.remove(mod)

            #convert to mesh for sanity

            mesh_name = ob.data.name
            ob.data.name = 'XXXX'
            # remove the old mesh
            if not ob.data.users:
                bpy.data.meshes.remove(ob.data)
            mesh = ob.to_mesh(scene, True, 'PREVIEW') # or 'RENDER'
            ob.modifiers.clear()
            mesh.name = mesh_name
            ob.data = mesh

            for name, settings in mod_dic.items():
                m = ob.modifiers.new(name, settings["type"])
                for s, v in settings.items():
                    if s == "type":
                        continue
                    setattr(m, s, v)


            #bpy.ops.object.convert(target='MESH')
            bpy.ops.object.mode_set(mode='EDIT')

            bpy.ops.mesh.reveal()
            bpy.ops.mesh.select_all(action='DESELECT')
            bpy.ops.mesh.select_all(action='TOGGLE')

            # remove creese and weight
            bpy.ops.transform.edge_bevelweight(value=-1)
            bpy.ops.transform.edge_crease(value=-1)

            #convert to Loop and Mark Sharp + Beveling
            bpy.ops.mesh.hide()
            bpy.ops.object.editmode_toggle()

            #add Bevel
            bpy.ops.object.modifier_add(type='BEVEL')
            bpy.context.object.modifiers["Bevel"].use_clamp_overlap = False
            bpy.context.object.modifiers["Bevel"].show_in_editmode = False
            bpy.context.object.modifiers["Bevel"].width = bevelwidth
            #bpy.context.object.modifiers["Bevel"].segments = 3
            bpy.context.object.modifiers["Bevel"].profile = 0.71
            bpy.context.object.modifiers["Bevel"].limit_method = 'WEIGHT'
            bpy.context.object.modifiers["Bevel"].angle_limit = angle
            bpy.context.object.modifiers["Bevel"].show_in_editmode = True

        #set Smoothing
        bpy.ops.object.shade_smooth()

        text = "(C)Step - Bevels Baked"


        return {'FINISHED'}

#############################
#Adrian's SStep Modified
#############################

class sstep2(bpy.types.Operator):
    '''SStep Technical Test'''
    bl_description = "sstep "
    bl_idname = "sstep2.objects"
    bl_label = "(s)step Technical Test"
    bl_options = {'REGISTER', 'UNDO'}

    items = [(x.identifier, x.name, x.description, x.icon)
             for x in bpy.types.Modifier.bl_rna.properties['type'].enum_items]

    modtypes = EnumProperty(name="Modifier Types",
                           items=[(id, name, desc, icon, 2**i) for i, (id, name, desc, icon) in enumerate(items)
                                   if id in ['BOOLEAN', 'MIRROR', 'BEVEL']],
                           description="Don't apply these",
                           default={'BEVEL', 'MIRROR'},
                           options={'ENUM_FLAG'})

    angle = FloatProperty(name="AutoSmooth Angle",
                          description="Set AutoSmooth angle",
                          default= radians(60.0),
                          min = 0.0,
                          max = radians(180.0),
                          subtype='ANGLE')

    bevelwidth = FloatProperty(name="Bevel Width Amount",
                               description="Set Bevel Width",
                               default=0.0200,
                               min =
                               0.002,
                               max =0.25)

    bevelsegments = IntProperty(name="Bevel Width Amount",
                               description="Set Bevel Segments",
                               default= 3,
                               min = 1,
                               max = 12)

    togglesharpening = BoolProperty(default = True)

    apply_all = BoolProperty(default = True)

    original_bevel = FloatProperty()

    ssharpangle = FloatProperty(name="SSharpening Angle", description="Set SSharp Angle", default= 30.0, min = 0.0, max = 180.0)

    #added additional properties.

    bweight = FloatProperty(name="Bevel Weight Amount",
                               description="Set Bevel Weight",
                               default= 1,
                               min = 0,
                               max = 1)

    togglemeshhiding = BoolProperty(default = True)

    # ADD A BOOLEAN PROPERTY TO DISCERN BETWEEN THE TWO ALTERNATE MODES and cstep mode
    @classmethod
    def poll(cls, context):
        ob = context.object
        if ob is None:
            return False
        return (ob.type == 'MESH')

    def draw(self, context):
        global cstepmode

        layout = self.layout

        box = layout.box()
        col = box.column()
        #col.prop(self, "modtypes", expand=True)
        #box.prop( self, 'ssharpangle', text = "SsharpAngle" )
        #box.prop( self, 'angle', text = "SmoothingAngle" )
        #box.prop( self, 'alternatemode', text = "Don't Recalculate")
        box.prop( self, 'bevelsegments', text = "BSegements")
        box.prop(self, 'bweight', text = "BWeight")
        box.prop(self, 'togglemeshhiding', text = "Hide Mesh At End")

       # AR = cant make it work for global variable
        box.prop( self,'cstepmode', text = "cStep fix")

    #If - Default Calculation / Else - Replacive Calculation
    def execute(self, context):

        scene = context.scene
        ob = context.object  # soapbox call don't use bpy.context as context is passed
        obs = context.selected_objects
        original_bevel = self.original_bevel
        bevelwidth = self.bevelwidth
        angle = self.angle
        bevelsegments = self.bevelsegments

        ssharpangle = self.ssharpangle
        ssharpangle = ssharpangle * (3.14159265359/180)

        bweight = self.bweight

        b = bpy.context.active_object

        mod_dic = {}
        if self.apply_all:
        # replace with
            mods = [m for m in ob.modifiers if m.type in self.modtypes]
            for mod in mods:

                mod_dic[mod.name] = {k:getattr(mod, k) for k in mod.bl_rna.properties.keys()
                                 if k not in ["rna_type"]}
                #print(mod_dic)
                ob.modifiers.remove(mod)

            mesh_name = ob.data.name
            ob.data.name = 'XXXX'

        # remove the old mesh
            if not ob.data.users:
                bpy.data.meshes.remove(ob.data)
            mesh = ob.to_mesh(scene, True, 'PREVIEW') # or 'RENDER'
            ob.modifiers.clear()
            mesh.name = mesh_name
            ob.data = mesh

            for name, settings in mod_dic.items():
                m = ob.modifiers.new(name, settings["type"])
                for s, v in settings.items():
                    if s == "type":
                        continue
                    setattr(m, s, v)

        #Start In Edit Mode
        bpy.ops.object.mode_set(mode='EDIT')

        #Now Sharpen It
        bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='EDGE')
        bpy.ops.mesh.select_all(action='DESELECT')

        #Selects Sharps From A Nothing Selection
        bpy.ops.mesh.edges_select_sharp(sharpness=ssharpangle)

        #And Then Adds Weight / Crease / Sharp
        bpy.ops.transform.edge_bevelweight(value=bweight)#sets to beweight
        bpy.ops.transform.edge_crease(value=1)
        bpy.ops.mesh.mark_sharp()

        #try hiding the mesh at the end of sstep
        if self.togglemeshhiding:
            bpy.ops.mesh.select_all(action='DESELECT')
            bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.mesh.hide()
        else:
            bpy.context.object.modifiers["Bevel"].segments = bevelsegments

        #Comes Out Of Edit Mode
        bpy.ops.object.editmode_toggle()
        bpy.ops.object.select_all(action='DESELECT')

        b.select = True

        bpy.context.object.data.auto_smooth_angle = angle
        bpy.ops.object.shade_smooth()
        bpy.context.object.modifiers["Bevel"].segments = bevelsegments

        text = "\n".join([ "(C)Step Mode_________(S)Step",
                           "Bevels : New Cuts Calculated"])


        return {'FINISHED'}
