import bpy
from .. utils.addons import addon_exists

recommended_addons = [
    ("mira_tools",          "Mira Tools",       "http://blenderartists.org/forum/showthread.php?366107-MiraTools"),
    ("asset_management",    "Asset Management", "https://gumroad.com/l/kANV/"),
    ("BoolTool",            "Bool Tool 0.2",    "https://github.com/vitorbalbio/code/tree/master/BoolTool"),
    ("QuickLatticeCreate",  "Easy Lattice",     "http://blenderaddonlist.blogspot.com/2013/10/addon-quick-easy-lattice-object.html"),
    ("MirrorMirrorTool",    "Mirror Mirror",    "https://gumroad.com/l/hardops/"),
    ("Batch Operations",    "Batch Operations", "http://wiki.blender.org/index.php/Extensions:2.6/Py/Scripts/3D_interaction/BatchOperations"),
    ("AutoMirror",          "Auto Mirror",      "http://blenderaddonlist.blogspot.com/2014/07/addon-auto-mirror.html"),
]

def draw_addon_diagnostics(layout, columns = 4):
    col = layout.column()
    for i, (identifier, name, url) in enumerate(recommended_addons):
        if i % columns == 0: row = col.row()
        icon = "FILE_TICK" if addon_exists(identifier) else "ERROR"
        row.operator("wm.url_open", text = name, icon = icon).url = url
    for i in range(0, columns - len(recommended_addons) % columns):
        row.label("")
