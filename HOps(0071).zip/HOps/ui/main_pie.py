import bpy
import os
from .. icons import get_icon_id, icons
from .. utils.addons import addon_exists
from .. preferences import use_asset_manager, get_preferences, pie_placeholder_1_enabled, pie_placeholder_2_enabled, pie_F6_enabled, pie_bool_options_enabled
from .. utils.objects import get_inactive_selected_objects

class HOpsMainPie(bpy.types.Menu):
    bl_idname = "hops_main_pie"
    bl_label = "Hard Ops 007(F)"

    def draw(self, context):
        layout = self.layout
        active_object = context.active_object

        if active_object is None:
            self.draw_without_active_object_pie(layout)
        elif active_object.mode == "OBJECT":
            self.draw_object_mode_pie(layout)
        elif active_object.mode == "EDIT":
            self.draw_edit_mode_pie(layout, active_object)


    # Without Selection
    ############################################################################

    def draw_without_active_object_pie(self, layout):
        wm = bpy.context.window_manager
        pie = self.layout.menu_pie()
        group = pie.column()
        box = group.box()
        row = box.row()
        row.operator("hops.asset_scroller_window", "(HOps)")
        row = box.row()
        row.template_icon_view(wm, "Hard_Ops_previews")
        row.template_icon_view(wm, "sup_preview")

        self.layout.menu_pie().row().label('')
        if addon_exists("asset_management"):
            box = pie.box()
            col = box.column()
            asset_manager = wm.asset_m
            col.prop(asset_manager, "libraries", text = "")
            col.prop(asset_manager, "categories", text = "")
            col.template_icon_view(wm, "AssetM_previews", show_labels = True)
        #ol.separator()
        else:
            self.layout.menu_pie().row().label('')

        #top
        self.layout.menu_pie().row().label('')
        self.layout.menu_pie().row().label('')

        box = pie.box()
        col = box.column()
        col.menu("renderSet.submenu", text="RenderSets", icon_value=get_icon_id("Gui"))
        col.menu("viewport.submenu", text="ViewPort", icon_value=get_icon_id("Viewport"))
        col.menu("settings.submenu", text="Settings", icon_value=get_icon_id("Gui"))

        self.layout.menu_pie().row().label('')
        self.layout.menu_pie().row().label('')




    # Always
    ############################################################################

    def draw_always_pie(self, layout):
        '''layout.separator()
        layout.menu("protomenu.submenu", text = "Operations", icon_value=get_icon_id("CST"))
        layout.separator()
        layout.menu("view3d.mstool_submenu", text = "MeshTools", icon_value=get_icon_id("Diagonal"))
        layout.menu("inserts.objects", text="Insert", icon_value=get_icon_id("Insert"))
        layout.menu("settings.submenu", text="Settings", icon_value=get_icon_id("Gui"))'''




    # Object Mode
    ############################################################################

    def draw_object_mode_pie(self, layout):
        active_object, other_objects, other_object = get_current_selected_status()
        only_meshes_selected = all(object.type == "MESH" for object in bpy.context.selected_objects)

        object = bpy.context.active_object
        pie = self.layout.menu_pie()

        if len(bpy.context.selected_objects) == 1:  
            if object.hops.status == "CSHARP":
                if active_object is not None and other_object is None and only_meshes_selected:
                        self.drawpie_only_with_active_object_is_csharpen(layout, active_object)

            if object.hops.status == "CSTEP":
                if active_object is not None and other_object is None and only_meshes_selected:
                    self.drawpie_only_with_active_object_is_cstep(layout, active_object)

            if object.hops.status == "UNDEFINED":
                if active_object is not None and other_object is None and only_meshes_selected:
                    self.drawpie_only_with_active_object(layout, active_object)


        elif len(bpy.context.selected_objects) == 2:  
            
            selected = bpy.context.selected_objects
            active = bpy.context.active_object
            selected.remove(active)
            object = selected[0]

            if object.hops.is_for_merge:
                if active_object is not None and other_object is not None and only_meshes_selected:
                    self.drawpie_with_active_object_and_other_mesh_for_merge(layout, active_object, other_object)

            elif object.hops.is_for_softmerge:
                if active_object is not None and other_object is not None and only_meshes_selected:
                    self.drawpie_with_active_object_and_other_mesh_for_softmerge(layout, active_object, other_object)

            else:
                if active_object is not None and other_object is not None and only_meshes_selected:
                    self.drawpie_with_active_object_and_other_mesh(layout, active_object, other_object)

        elif len(bpy.context.selected_objects) > 2:

            self.drawpie_with_active_object_and_other_mesh(layout, active_object, other_object)


        else:
            self.draw_without_active_object_pie(layout)


    def drawpie_only_with_active_object(self, layout, object):
        pie = self.layout.menu_pie()

        pie.operator("nw.solidify", text = "(T)Thick", icon_value=get_icon_id("Tthick"))
        if pie_placeholder_2_enabled():
           pie.operator("hops.soft_sharpen", text = "")
        else:
            self.layout.menu_pie().row().label('')
        pie.operator("hops.complex_sharpen", text = "(C) Sharpen", icon_value=get_icon_id("CSharpen"))
        self.draw_f6_option(layout)
        self.layout.menu_pie().row().label('')
        self.drawpie_options(layout)
        if pie_placeholder_1_enabled():
           pie.operator("hops.complex_sharpen", text = "") 
        else:
            self.layout.menu_pie().row().label('')
        pie.operator("hops.soft_sharpen", text = "(S) Sharpen", icon_value=get_icon_id("Ssharpen"))


    def drawpie_only_with_active_object_is_csharpen(self, layout, object):
        pie = self.layout.menu_pie()
        object = bpy.context.active_object
        if object.hops.is_pending_boolean:

            pie.operator("reverse.boolean", text = "(Re)Bool", icon_value=get_icon_id("ReBool"))
            if pie_placeholder_2_enabled():
               pie.operator("hops.complex_sharpen", text = "")
            else:
                self.layout.menu_pie().row().label('')
            pie.operator("hops.adjust_bevel", text = "(B)Width", icon_value=get_icon_id("AdjustBevel"))
            self.draw_f6_option(layout)
            self.layout.menu_pie().row().label('')
            self.drawpie_options(layout)
            if pie_placeholder_1_enabled():
                pie.operator("hops.adjust_bevel", text = "", icon_value=get_icon_id(""))
            else:
                self.layout.menu_pie().row().label('')
            pie.operator("hops.complex_sharpen", text = "(C) Sharpen", icon_value=get_icon_id("CSharpen"))

        else:
            pie.operator("step.cstep", text = "(C) Step", icon_value=get_icon_id("Cstep"))
            if pie_placeholder_2_enabled():
               pie.operator("hops.soft_sharpen", text = "")
            else:
                self.layout.menu_pie().row().label('')
            pie.operator("hops.adjust_bevel", text = "(B)Width", icon_value=get_icon_id("AdjustBevel"))
            self.draw_f6_option(layout)
            self.layout.menu_pie().row().label('')
            self.drawpie_options(layout)
            if pie_placeholder_1_enabled():
                pie.operator("hops.adjust_bevel", text = "", icon_value=get_icon_id(""))
            else:
                self.layout.menu_pie().row().label('')
            pie.operator("hops.soft_sharpen", text = "(S) Sharpen", icon_value=get_icon_id("Ssharpen"))


    def drawpie_only_with_active_object_is_cstep(self, layout, object):
        pie = self.layout.menu_pie()
        object = bpy.context.active_object

        pie.operator("step.cstep", text = "(C) Step", icon_value=get_icon_id("Cstep"))
        if pie_placeholder_2_enabled():
           pie.operator("step.sstep", text = "")
        else:
            self.layout.menu_pie().row().label('')
        if object.hops.is_pending_boolean:
            pie.operator("reverse.bools", text = "(Re)Bool-Sstep", icon_value=get_icon_id("ReBool"))
        else:
            pie.operator("hops.adjust_bevel", text = "(B)Width", icon_value=get_icon_id("AdjustBevel"))
        self.draw_f6_option(layout)
        self.layout.menu_pie().row().label('')
        self.drawpie_options(layout)
        if pie_placeholder_1_enabled():
            if object.hops.is_pending_boolean:
                pie.operator("reverse.bools", text = "", icon_value=get_icon_id(""))
            else:
                pie.operator("hops.adjust_bevel", text = "", icon_value=get_icon_id(""))
        else:
            self.layout.menu_pie().row().label('')
        pie.operator("step.sstep", text = "(S) Step", icon_value=get_icon_id("Sstep"))

    def drawpie_with_active_object_and_other_mesh(self, layout, active_object, other_object):
        pie = self.layout.menu_pie()
        object = bpy.context.active_object

        pie.operator("step.cstep", text = "(C) Step", icon_value=get_icon_id("Cstep"))
        if pie_placeholder_2_enabled():
            if object.hops.status == "CSTEP":
                pie.operator("step.sstep", text = "")
            else:
                pie.operator("hops.complex_sharpen", text = "")
        else:
            self.layout.menu_pie().row().label('')
        pie.operator("hops.complex_split_boolean", text = "(C)Split", icon_value=get_icon_id("Csplit"))
        self.draw_f6_option(layout)
        self.drawpie_bool_options(layout)
        self.drawpie_options(layout)
        if pie_placeholder_1_enabled():
            pie.operator("hops.complex_split_boolean", text = "", icon_value=get_icon_id(""))
        else:
            self.layout.menu_pie().row().label('')
        if object.hops.status == "CSTEP":
            pie.operator("step.sstep", text = "(S) Step", icon_value=get_icon_id("Sstep"))
        else:
            pie.operator("hops.complex_sharpen", text = "(C) Sharpen", icon_value=get_icon_id("CSharpen"))


    def drawpie_with_active_object_and_other_mesh_for_merge(self, layout, active_object, other_object):
        pie = self.layout.menu_pie()

        pie.operator("hops.complex_sharpen", text = "(C) Sharpen", icon_value=get_icon_id("CSharpen"))
        if pie_placeholder_2_enabled():
           pie.operator("hops.parent_merge", text = "")
        else:
            self.layout.menu_pie().row().label('')
        pie.operator("hops.complex_split_boolean", text = "(C)Split", icon_value=get_icon_id("Csplit"))
        self.draw_f6_option(layout)
        self.layout.menu_pie().row().label('')
        self.drawpie_options(layout)
        if pie_placeholder_1_enabled():
            pie.operator("hops.complex_split_boolean", text = "", icon_value=get_icon_id(""))
        else:
            self.layout.menu_pie().row().label('')
        pie.operator("hops.parent_merge", text = "Merge", icon_value = get_icon_id("CSharpen"))




    def drawpie_with_active_object_and_other_mesh_for_softmerge(self, layout, active_object, other_object):
        pie = self.layout.menu_pie()

        pie.operator("hops.complex_sharpen", text = "(C) Sharpen", icon_value=get_icon_id("CSharpen"))
        if pie_placeholder_2_enabled():
           pie.operator("hops.parent_merge_soft", text = "")
        else:
            self.layout.menu_pie().row().label('')
        pie.operator("hops.complex_split_boolean", text = "(C)Split", icon_value=get_icon_id("Csplit"))
        self.draw_f6_option(layout)
        self.layout.menu_pie().row().label('')
        self.drawpie_options(layout)
        if pie_placeholder_1_enabled():
            pie.operator("hops.complex_split_boolean", text = "", icon_value=get_icon_id(""))
        else:
            self.layout.menu_pie().row().label('')
        pie.operator("hops.parent_merge_soft", text = "Merge(soft)", icon_value = get_icon_id("CSharpen"))

    def drawpie_options(self, layout): 
        pie = self.layout.menu_pie()  
        box = pie.box()
        col = box.column()  
        col.menu("protomenu.submenu", text = "Operations", icon_value=get_icon_id("CST"))
        col.menu("view3d.mstool_submenu", text = "MeshTools", icon_value=get_icon_id("Diagonal"))
        col.menu("inserts.objects", text="Insert", icon_value=get_icon_id("Insert"))
        col.menu("settings.submenu", text="Settings", icon_value=get_icon_id("Gui"))

    def drawpie_bool_options(self, layout): 
        if pie_bool_options_enabled() and addon_exists("BoolTool"):
            pie = self.layout.menu_pie()  
            box = pie.box()
            row = box.row() 
            row.operator("btool.boolean_inters", text="Intersection")
            row.operator("btool.boolean_union", text="Union")
            row.operator("btool.boolean_diff", text="Difference")
        else:
            self.layout.menu_pie().row().label('')

    def draw_f6_option(self, layout):
        pie = self.layout.menu_pie()
        if pie_F6_enabled():
            pie.operator("screen.redo_last", text="F6", icon='SCRIPTWIN')
        else:
            self.layout.menu_pie().row().label('')



       


    # Edit Mode
    ############################################################################

    def draw_edit_mode_pie(self, layout, object):
        pie = self.layout.menu_pie()  
        #left
        self.layout.menu_pie().row().label('')
        #right
        self.layout.menu_pie().row().label('')
        #bot
        pie.operator("transform.edge_bevelweight", text = "Bweight", icon_value = get_icon_id("AdjustBevel"))
        #top
        self.layout.menu_pie().row().label('')
        #top L
        self.layout.menu_pie().row().label('')
        #top R
        box = pie.box()
        col = box.column() 
        col.menu("view3d.emstool_submenu", text = "MeshTools", icon_value = get_icon_id("Diagonal"))
        if addon_exists("mira_tools"):
            col.menu("mira.submenu", text = "Mira (T)", icon_value = get_icon_id("Mira"))
        col.operator("ehalfslap.object", text = "xSymmetrize", icon_value = get_icon_id("Xslap"))
        if object.data.show_edge_crease == False:
            col.operator("object.showoverlays", text = "Show Overlays", icon = "RESTRICT_VIEW_ON")
        else :
            col.operator("object.hide_overlays", text = "Hide Overlays", icon = "RESTRICT_VIEW_OFF")
        col.menu("inserts.objects", text = "Insert", icon_value = get_icon_id("Insert"))
        #bot L
        pie.operator("bevelandsharp1.objects", text = "Make SSharp", icon_value = get_icon_id("MarkSharpE"))
        #bot R
        pie.operator("clean1.objects", text = "Clean SSharps", icon_value = get_icon_id("ClearSharps"))

def get_current_selected_status():
    active_object = bpy.context.active_object
    other_objects = get_inactive_selected_objects()
    other_object = None
    if len(other_objects) == 1:
            other_object = other_objects[0]

    return active_object, other_objects, other_object