import os
import bpy
import rna_keymap_ui
from bpy.props import *
from . utils.addons import addon_exists
from . ui.addon_checker import draw_addon_diagnostics
from . utils.blender_ui import write_text, get_dpi_factor

#line for the panel
from . gui_panel_obm import (HardOps_Panel_OBM)
from . gui_panel_edm import (HardOps_Panel_EDM)

def get_preferences():
    name = get_addon_name()
    return bpy.context.user_preferences.addons[name].preferences

def get_addon_name():
    return os.path.basename(os.path.dirname(os.path.realpath(__file__)))


# Specific preference settings

def tool_overlays_enabled():
    return get_preferences().enable_tool_overlays

def pie_placeholder_1_enabled():
    return get_preferences().pie_placeholder_1

def pie_placeholder_2_enabled():
    return get_preferences().pie_placeholder_2

def pie_F6_enabled():
    return get_preferences().pie_F6

def pie_bool_options_enabled():
    return get_preferences().pie_bool_options

def use_asset_manager():
    return get_preferences().Asset_Manager_Preview and addon_exists("asset_management")



#Tool Panel for update category and hide panel
def update_HardOps_Panel_Tools(self, context):
    panel = getattr(bpy.types, "hops_main_panel", None)
    if panel is not None:
        bpy.utils.unregister_class(panel)
        panel.bl_category = get_preferences().toolbar_category_name
        bpy.utils.register_class(panel)

def category_name_changed(self, context):
    category = get_preferences().toolbar_category_name
    change_hard_ops_category(category)

settings_tabs_items = [
    ("UI", "UI", ""),
    ("INFO", "Info", ""),
    ("KEYMAP", "Keymap", ""),
    ("LINKS", "Links", ""),
    ("ADDONS", "Recommended Addons", "") ]

class HardOpsPreferences(bpy.types.AddonPreferences):
    bl_idname = get_addon_name()

    tab = EnumProperty(name = "Tab", items = settings_tabs_items)

    toolbar_category_name = StringProperty(name = "Toolbar Category", default = "HardOps",
            description = "Name of the tab in the toolshelf in the 3d view",
            update = category_name_changed)

    enable_tool_overlays = BoolProperty(name = "Enable Tool Overlays", default=True)

    Asset_Manager_Preview = BoolProperty(name = "Asset Manager Preview", default=False)
    Diagnostics_Mode = BoolProperty(name = "Debug Mode", default=False)
    Relink_options = BoolProperty(name = "Re-Link Options", default=False)

    pie_placeholder_1 = bpy.props.BoolProperty(name="Pie Placeholder 1", default=False,
            description="add placehoder button to pie menu")

    pie_placeholder_2 = bpy.props.BoolProperty(name="Pie Placeholder 2", default=False,
            description="add placehoder button to pie menu")

    pie_F6 = bpy.props.BoolProperty(name="Pie F6", default=False,
            description="add F6 button to pie menu")

    pie_bool_options = bpy.props.BoolProperty(name="Pie Bool Options", default=True,
            description="add bool button to pie menu")

    def draw(self, context):
        layout = self.layout

        col = layout.column(align = True)
        row = col.row()
        row.prop(self, "tab", expand = True)

        box = col.box()

        if self.tab == "UI":
            self.draw_ui_tab(box)
        elif self.tab == "INFO":
            self.draw_info_tab(box)
        elif self.tab == "KEYMAP":
            self.draw_keymap_tab(box)
        elif self.tab == "LINKS":
            self.draw_links_tab(box)
        elif self.tab == "ADDONS":
            self.draw_addons_tab(box)

    def draw_ui_tab(self, layout):
        #layout.prop(self, "toolbar_category_name")
        layout.prop(self, "enable_tool_overlays")
        row = layout.row()
        row.prop(self, "pie_F6", text = "Pie: F6 Option At Top")
        #row.prop(self, "pie_placeholder_1")
        #row.prop(self, "pie_placeholder_2")
        row = layout.row() 
        row.prop(self, "pie_bool_options", text = "Pie: Add Boolean Options")

        row = layout.row()
        if addon_exists("asset_management"):
            row.label("Asset Manager Found!")
            row.prop(self, "Asset_Manager_Preview", text = "Asset Manager: Add To HOps")
        if addon_exists("relink"):
            row = layout.row()
            row.label("Re-Link Found!")
            row.prop(self, "Relink_options", text = "Re-Link: Options")
            #row = layout.row()
            row.prop(self, "Diagnostics_Mode", text = "Diagnostics: Show Info")

    def draw_info_tab(self, layout):
        write_text(layout, info_text, width = bpy.context.region.width / get_dpi_factor() / 8)

    def draw_keymap_tab(self, layout):
        layout.label("By default (Q) is menu and (Shift+Q) is pie")
        layout.label("There is also a button to edit the script below. Not recommended")
        layout.operator("hops.open_keymap_for_editing")

    def draw_links_tab(self, layout):
        col = layout.column()
        for name, url in weblinks:
            col.operator("wm.url_open", text = name).url = url

    def draw_addons_tab(self, layout):
        draw_addon_diagnostics(layout, columns = 2)


info_text = """HardOps is a toolset to maximize hard surface efficiency. I personally wanted
this to be a toolkit for workflows of my style. But as this add-on has developed
so has my style. The support of the Hard Ops team has made this into a masterpiece.
Tools are built to be used for concept mesh creation. The goal is speed but also
fine surfaces. With bevels. Leave your topology at the door. Just have fun! There is 
documentation on my blog if you have issues using it not to mention to many demos of it! Feel 
free to write about improvements or getting involved! Thank you for your support.


License Code: 29468741xxxx4x5  haha just kidding! This.... is... Blender!
""".replace("\n", " ")

weblinks = [
    ("Youtube",                 "https://www.youtube.com/user/masterxeon1001/"),
    ("Gumroad",                 "https://gumroad.com/l/hardops/"),
    ("Intro Guide",             "https://masterxeon1001.wordpress.com/hard-ops-intro-guide/"),
    ("CSlice Guide",            "https://masterxeon1001.wordpress.com/hard-ops-intro-guide/hard-ops-cslice/"),
    ("C/Step Guide",            "https://masterxeon1001.wordpress.com/hard-ops-intro-guide/hard-ops-cstep-sstep/"),
    ("Meshtools (Edit) Guide",  "https://masterxeon1001.wordpress.com/hard-ops-intro-guide/hard-ops-meshtools-edit-mode/"),
    ("Settings Guide",          "https://masterxeon1001.wordpress.com/hard-ops-intro-guide/hard-ops-settingsmenu/"),
]
